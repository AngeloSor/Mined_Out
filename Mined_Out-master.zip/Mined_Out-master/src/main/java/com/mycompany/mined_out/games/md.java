/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mined_out.games;

import com.mycompany.mined_out.GameDescription;
import com.mycompany.mined_out.jFrame;
import com.mycompany.mined_out.parser.ParserOutput;
import com.mycompany.mined_out.type.AdvObject;
import com.mycompany.mined_out.type.AdvObjectContainer;
import com.mycompany.mined_out.type.Command;
import com.mycompany.mined_out.type.CommandType;
import com.mycompany.mined_out.type.Room;
import java.io.PrintStream;

/**
 *
 * @author giuse
 */
public class md extends GameDescription {

    @Override
    public void init() throws Exception {

        //definizione comandi
        Command nord = new Command(CommandType.NORD, "nord");
        nord.setAlias(new String[]{"n", "N", "Nord", "NORD"});
        getCommands().add(nord);
        Command iventory = new Command(CommandType.INVENTORY, "inventario");
        iventory.setAlias(new String[]{"inv", "i", "I"});
        getCommands().add(iventory);
        Command sud = new Command(CommandType.SOUTH, "sud");
        sud.setAlias(new String[]{"s", "S", "Sud", "SUD"});
        getCommands().add(sud);
        Command est = new Command(CommandType.EAST, "est");
        est.setAlias(new String[]{"E", "Est", "EST"});
        getCommands().add(est);
        Command ovest = new Command(CommandType.WEST, "ovest");
        ovest.setAlias(new String[]{"O", "Ovest", "OVEST"});
        getCommands().add(ovest);
        Command end = new Command(CommandType.END, "end");
        end.setAlias(new String[]{"end", "fine", "esci", "muori", "ammazzati", "ucciditi", "suicidati", "exit"});
        getCommands().add(end);
        Command look = new Command(CommandType.LOOK_AT, "osserva");
        look.setAlias(new String[]{"guarda", "vedi", "trova", "cerca", "descrivi"});
        getCommands().add(look);
        Command pickup = new Command(CommandType.PICK_UP, "raccogli");
        pickup.setAlias(new String[]{"prendi"});
        getCommands().add(pickup);
        Command open = new Command(CommandType.OPEN, "apri");
        open.setAlias(new String[]{});
        getCommands().add(open);
        Command push = new Command(CommandType.PUSH, "premi");
        push.setAlias(new String[]{"spingi", "attiva"});
        getCommands().add(push);
        Command use = new Command(CommandType.USE, "usa");
        use.setAlias(new String[]{"utilizza"});
        getCommands().add(use);

        //definizione stanze
        Room Stanza1 = new Room(1, "Stanza1", "Sei entrato nella miniera, prosegui");
        Stanza1.setLook("C'è un binario col carrello, non è funzionante, ma vedi una casseta degli attrezzi ed un piccone, potrebbe servirti");

        Room Stanza2 = new Room(2, "Stanza2", "Sei riuscito ad aggiustare il carrello, però non riesci a proseguire, perchè c'è un muro sul percorso, come puoi abbatterlo?");
        Stanza2.setLook("Non c'è niente");
        Stanza2.setIsAccessible(false);

        Room Stanza3 = new Room(3, "Stanza3", "Hai abbattuto il muro, ma intravedi un bivio. A destra non c'è luce, a sinistra ");
        Stanza3.setLook("Non c'è niente");
        Stanza3.setIsAccessible(false);

        //MAPPA
        Stanza1.setNorth(Stanza2);
        getRooms().add(Stanza1);

        Stanza2.setNorth(Stanza3);
        Stanza2.setSouth(Stanza1);
        getRooms().add(Stanza1);

        Stanza3.setSouth(Stanza2);
        getRooms().add(Stanza3);

        //oggetti 
        AdvObject carrello = new AdvObject(0, "carrello", "carrello");
        carrello.setAlias(new String[]{});
        carrello.setUsable(false);
        Stanza1.getObjects().add(carrello);

        AdvObject tritolo = new AdvObject(1, "tritolo", "pacco di TNT");
        tritolo.setAlias(new String[]{"esplosivo", "TNT"});
        Stanza1.getObjects().add(tritolo);

        AdvObject chiaveInglese24 = new AdvObject(2, "chiave", "chiave inglese");
        chiaveInglese24.setAlias(new String[]{"chiaveinglese"});
        Stanza1.getObjects().add(chiaveInglese24);

        AdvObject fiammiferi = new AdvObject(3, "fiammiferi", "fiammiferi");
        fiammiferi.setAlias(new String[]{"fiammiferi", "fiamma"});
        Stanza1.getObjects().add(fiammiferi);

        AdvObject cacciavite = new AdvObject(4, "cacciavite", "Hai trovato un cacciavite");
        cacciavite.setAlias(new String[]{"giravite", "avvitatore", "caccia vite"});
        Stanza1.getObjects().add(cacciavite);

        AdvObject piccone = new AdvObject(5, "piccone", "un piccone");
        piccone.setAlias(new String[]{"piccozza"});
        Stanza1.getObjects().add(piccone);

        AdvObjectContainer cassettaAttrezzi = new AdvObjectContainer(2, "Cassetta", "Cassetta degli attrezzi, interessante!!");
        cassettaAttrezzi.setAlias(new String[]{"cassetta", "attrezzi"});
        cassettaAttrezzi.setOpenable(true);
        cassettaAttrezzi.setPickupable(false);
        cassettaAttrezzi.setOpen(false);
        Stanza1.getObjects().add(cassettaAttrezzi);
        cassettaAttrezzi.add(tritolo);
        //cassettaAttrezzi.add(chiaveInglese24);
        cassettaAttrezzi.add(fiammiferi);
        cassettaAttrezzi.add(cacciavite);

        Stanza2.getObjects().add(cassettaAttrezzi);

        //impostazione stanza iniziale
        setCurrentRoom(Stanza1);
    }

    @Override
    public String nextMove(ParserOutput p, PrintStream out) {
        String Output=null;
        int moveStatus = 0;
        if (p.getCommand() == null) {
            Output = "Che dovrei fare?? Non ho capito";
        } else //comandi di movimento
        {

            if (p.getCommand().getType() == CommandType.NORD) {

                if (getCurrentRoom().getNorth() != null) {
                    moveStatus = 1;
                    if (getCurrentRoom().getNorth().isIsAccessible() == true) {
                        setCurrentRoom(getCurrentRoom().getNorth());
                        moveStatus = 2;
                    } else {
                        moveStatus = -2;
                    }

                } else {
                    moveStatus = -1;
                }
            }

            if (p.getCommand().getType() == CommandType.SOUTH) {

                if (getCurrentRoom().getSouth() != null) {
                    moveStatus = 1;
                    if (getCurrentRoom().getSouth().isIsAccessible() == true) {
                        setCurrentRoom(getCurrentRoom().getSouth());
                        moveStatus = 2;
                    } else {
                        moveStatus = -2;
                    }

                } else {
                    moveStatus = -1;
                }
            }

            if (p.getCommand().getType() == CommandType.EAST) {

                if (getCurrentRoom().getEast() != null) {
                    moveStatus = 1;
                    if (getCurrentRoom().getEast().isIsAccessible() == true) {
                        setCurrentRoom(getCurrentRoom().getEast());
                        moveStatus = 2;
                    } else {
                        moveStatus = -2;
                    }

                } else {
                    moveStatus = -1;
                }
            }

            if (p.getCommand().getType() == CommandType.WEST) {

                if (getCurrentRoom().getWest() != null) {
                    moveStatus = 1;
                    if (getCurrentRoom().getWest().isIsAccessible() == true) {
                        setCurrentRoom(getCurrentRoom().getWest());
                        moveStatus = 2;
                    } else {
                        moveStatus = -2;
                    }

                } else {
                    moveStatus = -1;
                }
            }
        }

        if (moveStatus == 2) {
            Output = (" Ti trovi nella stanza: " + getCurrentRoom().getName());
            Output = (" Descrizione: " + getCurrentRoom().getDescription());
        }
        if (moveStatus == -2) {
            Output = (" Mi spiace devi risolvere il problema, prova con ciò che hai trovato fin ora!");
        }

        if (moveStatus == -1) {
            Output = (" Non puoi anadare in questa direzione, ci sono molte alternative, scegli quella corretta!");
        }

        //comandi di visione stanza
        {
            if (p.getCommand().getType() == CommandType.LOOK_AT) {
                if (getCurrentRoom().getLook() != null) {
                    Output = (getCurrentRoom().getLook());
                }else{
                    Output = "Non c'è nulla da vedere qui!";
                }
            }
        }

        //comandi di visione inventario
        {

            if (p.getCommand().getType() == CommandType.INVENTORY) {

                if (!(getInventory().isEmpty())) {
                    Output = ("Nel tuo inventario ci sono:");
                    for (AdvObject o : getInventory()) {
                      Output = Output.concat(o.getName() + ": " + o.getDescription());
                    }

                } else {
                    Output = (" Il tuo inventario è vuoto");
                }
            }
        }

        //comandi di presa oggetti
        {
            if (p.getCommand().getType() == CommandType.PICK_UP) {
                if (p.getObject() != null) {
                    if (p.getObject().isPickupable()) {
                        getInventory().add(p.getObject());
                        getCurrentRoom().getObjects().remove(p.getObject());
                        Output = ("Hai raccolto: " + p.getObject().getDescription());
                    } else {
                        Output = ("Non puoi raccogliere questo oggetto.");
                    }
                } else {
                    Output = ("Non c'è niente da raccogliere qui.");
                }
            }
        }

        if (p.getCommand().getType() == CommandType.END) {
            Output = "exit";
        }
        //comandi per utilizzare un oggetto
        {
            if (p.getCommand().getType() == CommandType.USE) {
                if (p.getObject() != null) {
                    if (p.getObject().isUsable()) {
                        useLogic(p, System.out);
                    } else {
                        Output = (" Non puoi utilizzare questo oggetto. Ingegnati!! ");
                    }

                } else {
                    Output = " Che dovrei utilizzare??";
                }

            }
        }
        return Output;
    }

    public void useLogic(ParserOutput p, PrintStream out) {

//caso stanza uno e si vuole aggiustare il carrello
        if (getCurrentRoom().getId() == 1) {

            if (p.getObject().getId() == 2) {

                if (!(getInventory().isEmpty())) {

                    for (AdvObject o : getInventory()) {
                        if (o.getId() == 2) {

                            for (AdvObject w : getCurrentRoom().getObjects()) { //se la chiave è nell'inventario imposta il carrello come usabile

                                if (w.getId() == 0) {
                                    w.setUsable(true);
                                    for(Room r : getRooms()){
                                        if(r.getId() == 2){
                                            r.setIsAccessible(true);
                                        }
                                    }
                                }
                            }
                        } else {
                            Output = (" Devi prima raccogliere " + p.getObject().getName());
                        }
                    }
                } else {
                    Output = (" Devi prima raccogliere " + p.getObject().getName());
                }

            }
        }

    }

}
