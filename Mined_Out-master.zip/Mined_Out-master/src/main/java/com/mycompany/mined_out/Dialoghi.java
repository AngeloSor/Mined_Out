/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mined_out;

public class Dialoghi {

    private static String introduzione = "\nIl tuo aereo precipita per un malfunzionamento in un bosco e ti ritrovi sperduto.\n"
            + " In più si sta facendo notte ed il tempo sta peggiorando, in più non hai alcun rifugio.\n"
            + " Vagando per pochi passi trovi una botola e decidi di entrarci come riparo dalla notte\n quando improvvisamente il vento fortissimo la chiude alla tue spalle.\n"
            + " La tua avventura inizia qui!";

    public static  String getIntroduzione() {
        return introduzione;

    }
    
    private static String conclusione = "\n Finalmente ora sei libero, adesso che hai imparato come si fa il carpentiere fatti una vita!";

    public static String getConclsione() {
        return conclusione;

    }
}
