/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mined_out;

//import di.uniba.map.b.adventure.games.FireHouseGame;
import com.mycompany.mined_out.games.md;
import com.mycompany.mined_out.parser.Parser;
import com.mycompany.mined_out.parser.ParserOutput;
import com.mycompany.mined_out.type.CommandType;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;

public class Engine {
    
    

    private final GameDescription game;

    private Parser parser;

    public Engine(GameDescription game) {
        this.game = game;
        try {
            this.game.init();
        } catch (Exception ex) {
            System.err.println(ex);
        }
        try {
            Set<String> stopwords = Utils.loadFileListInSet(new File("./resources/stopwords"));
            parser = new Parser(stopwords);
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    public void execute() {
        

        System.out.println("\n 1 ");
       
        //scrittura della storia iniziale
        //richiama il metodo

        System.out.println("\n 2");
       
        
        System.out.println(game.getCurrentRoom().getName());
        System.out.println();
        System.out.println(game.getCurrentRoom().getDescription());
        System.out.println();

        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNextLine()) {

            String command = scanner.nextLine();

            ParserOutput p = parser.parse(command, game.getCommands(), game.getCurrentRoom().getObjects(), game.getInventory());
            if (p.getCommand() != null && p.getCommand().getType() == CommandType.END) {
                System.out.println("Grazie per aver utilizzato Ferramenta 2.0!");
                break;
            } else {
                game.nextMove(p, System.out);
                System.out.println();
            }

        }
    }
    
    public String mossa(String mos){
        
        String s = null;
        ParserOutput p = parser.parse(mos, game.getCommands(), game.getCurrentRoom().getObjects(), game.getInventory());
            
                
            
               s=  game.nextMove(p, System.out);
                
            
            return s;
    }

   

}
