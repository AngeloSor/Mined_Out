# Mined_Out


Avventura testuale e grafica basata su una semplice storia.<br>
La stessa ha inizio in un bosco, in cui il protagonista si trova a causa di un incidente di volo.
Cercando la via d'uscita intravede una botola in cui entra, ma non può più uscire.
L'unico modo per salvarsi è risolvere enigmi e aggirare ostacoli. <br>
Buona fortuna!!

Soluzione del gioco(molto semplice):<br>
-nella stanza 1 raccogliere gli oggetti dalla cassetta, e quelli fuori dalla stanza <br>
-utilizzare la chiave inglese da 24 per rendere utilizzabile il carrello<br>
-nella stanza 2 utilizzare il tritolo o il piccone per abbattere iln muro<br>
-nella stanza 3 se si sceglie est si ritorna alla stanza, altrimenti scegliendo ovest si prosegue nel gioco<br>
